const { executeQuery, sql } = require('../database');

const getContentHistory = async (req, res) => {
    try {
        const query = 'SELECT * FROM "history"';
        const contentHistory = await executeQuery(query);
        res.status(200).json({
            result: 1,
            message: 'get content history successfully',
            data: contentHistory
        });
    } catch (error) {
        console.error('Error fetching content history:', error);
        res.status(500).json({
            result: 0,
            message: 'Error fetching content history',
            error: error.message
        });
    }
}

const createContentHistory = async (req, res) => {
    try {
        const { userid, copycontent } = req.body;
        const query = `INSERT INTO "history" ("userid", "copycontent") VALUES (@userid, @copycontent)`;
        await executeQuery(query, { userid: userid, copycontent: copycontent });
        res.status(200).json({
            result: 1,
            message: 'create content history successfully',
            data: { userid, copycontent },
        });
    } catch (error) {
        console.error('Error creating content history:', error);
        res.status(500).json({
            result: 0,
            message: 'Error creating content history',
            error: error.message
        });
    }
}

const deletehistory = async (req, res) => {
    try {
        const contentId = req.params.id;
        const query = `DELETE FROM "history" WHERE "id" = @contentId`;
        await executeQuery(query, { contentId: contentId });
        res.status(200).json({
            result: 1,
            message: 'delete content history successfully',
            data: { contentId },
        });
    } catch (error) {
        console.error('Error deleting content history:', error);
        res.status(500).json({
            result: 0,
            message: 'Error deleting content history',
            error: error.message
        });
    }
}

module.exports = {
    getContentHistory, createContentHistory, deletehistory,
};