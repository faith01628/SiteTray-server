const { executeQuery, sql } = require('../database');

const getAdmin = async (req, res) => {
    try {
        const query = 'SELECT * FROM "admin"';
        const adminData = await executeQuery(query);

        res.status(200).json({
            result: 1,
            message: 'get admin successfully',
            data: adminData,
        });

    } catch (error) {
        console.error('Error fetching admin data:', error);
        res.status(500).json({
            result: 0,
            message: 'Error fetching admin data',
            error: error.message,
        });
    }
};
const getAđminById = async (req, res) => {
    try {
        const adminId = req.params.id;

        const query = `
            SELECT * FROM "admin" WHERE id = @adminId
        `;

        const adminData = await executeQuery(query, { adminId });

        if (adminData.length > 0) {
            res.status(200).json({
                result: 1,
                message: 'get admin by id successfully',
                data: adminData
            });
        } else {
            res.status(404).json({
                result: 3,
                message: 'admin not found',
                data: []
            });
        }
    } catch (error) {
        console.error('Error getting admin by ID:', error);
        res.status(500).json({
            result: 0,
            message: 'Error getting admin by ID',
            error: error.message,
        });
    }
};

const updateAdmin = async (req, res) => {
    try {
        const userId = req.params.id;
        const { username, phone, code, email, address, edit, change } = req.body;

        const checkUserQuery = `SELECT * FROM "user" WHERE id = @userId`;
        const existingUser = await executeQuery(checkUserQuery, { userId });
        console.log(existingUser);

        let phoneExists = false;
        let emailExists = false;
        let codeExists = false;

        for (let i = 0; i < existingUser.length; i++) {
            if (existingUser[i].phone === phone) {
                phoneExists = true;
                break;
            }
            if (existingUser[i].email === email) {
                emailExists = true;
                break;
            }
            if (existingUser[i].code === code) {
                codeExists = true;
                break;
            }
        }

        if (!existingUser || existingUser.length === 0) {
            console.log('User not found');
            return res.status(404).json({
                result: 3,
                error: 'User not found',
                data: []
            });
        }

        if (!username || !phone || !email || !address || !code) {
            console.log('Missing information. Please provide all required fields.');
            return res.status(400).json({
                result: 2,
                message: 'Missing information. Please provide all required fields.',
                data: []
            });
        } else if (phoneExists) {
            console.log('This phone already exists');
            return res.status(400).json({
                result: 2,
                message: 'This phone already exists',
                data: []
            })
        } else if (codeExists) {
            console.log('This code already exists');
            return res.status(400).json({
                result: 2,
                message: 'This code already exists',
                data: []
            })
        } else if (emailExists) {
            console.log('This email already exists');
            return res.status(400).json({
                result: 2,
                message: 'This email already exists',
                data: []
            })
        }
        const updateQuery = `
        UPDATE "user"
        SET username = @username, phone = @phone, code = @code,
            email = @email, address = @address,
            edit = @edit, change = @change
        WHERE id = @userId
    `;
        const updateResult = await executeQuery(updateQuery, {
            userId,
            username,
            phone,
            code,
            email,
            address,
            edit,
            change
        });

        res.status(200).json({
            result: 1,
            message: 'User updated successfully',
            data: {
                id: userId,
                username: username,
                phone: phone,
                code: code,
                email: email,
                address: address,
            }
        });
    } catch (error) {
        console.error('Error updating user:', error);
        res.status(500).json({
            result: 0,
            message: 'Error updating user',
            error: error.message,
        });
    }
};

module.exports = {
    getAdmin, getAđminById, updateAdmin,
};