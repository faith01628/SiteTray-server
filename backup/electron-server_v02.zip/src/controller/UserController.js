const { executeQuery, sql } = require('../database');

const getUserData = async (req, res) => {
    try {
        const query = 'SELECT * FROM "user"';
        const userData = await executeQuery(query);

        res.status(200).json({
            result: 1,
            message: 'get user successfully',
            data: userData,
        });

    } catch (error) {
        console.error('Error fetching user data:', error);
        res.status(500).json({
            result: 0,
            message: 'Error fetching user data',
            error: error.message,
        });
    }
};

const createUser = async (req, res) => {
    try {
        const { username, phone, email, address, code } = req.body;

        const checkUserQuery = `SELECT * FROM "user"`;
        const existingUser = await executeQuery(checkUserQuery);

        let phoneExists = false;
        let emailExists = false;
        let codeExists = false;
        for (let i = 0; i < existingUser.length; i++) {
            if (existingUser[i].phone === phone) {
                phoneExists = true;
                break;
            }
            if (existingUser[i].email === email) {
                emailExists = true;
                break;
            }
            if (existingUser[i].code === code) {
                codeExists = true;
                break;
            }
        }

        if (!username || !phone || !email || !address || !code) {
            return res.status(400).json({
                result: 2,
                message: 'Missing information. Please provide all required fields.',
                data: []
            });
        } else if (emailExists) {
            return res.status(400).json({
                result: 2,
                message: 'This email already exists',
                data: []
            })
        } else if (phoneExists) {
            return res.status(400).json({
                result: 2,
                message: 'This phone already exists',
                data: []
            })
        } else if (codeExists) {
            return res.status(400).json({
                result: 2,
                message: 'This code already exists',
                data: []
            })
        } else {
            const query = `
            INSERT INTO [user] (username, phone, email, address, code, edit, change)
            VALUES (@username, @phone, @email, @address, @code, 1, 1)
            `;

            await executeQuery(query, {
                username: username,
                phone: phone,
                email: email,
                address: address,
                code: code,
            });
        }

        res.status(201).json({
            result: 0,
            message: 'User created successfully',
            data: {
                username,
                phone,
                email,
                address,
                code,
            }
        });

    } catch (error) {
        console.error('Error creating user:', error);
        res.status(500).json({
            result: 0,
            message: 'Error creating user',
            error: error.message,
        });
    }
};


const getUserById = async (req, res) => {
    try {
        const userId = req.params.id;

        const query = `
            SELECT * FROM "user" WHERE id = @userId
        `;

        const userData = await executeQuery(query, { userId });

        if (userData.length > 0) {
            res.status(200).json({
                result: 1,
                message: 'get user by id successfully',
                data: userData
            });
        } else {
            res.status(404).json({
                result: 3,
                message: 'User not found',
                data: []
            });
        }
    } catch (error) {
        console.error('Error getting user by ID:', error);
        res.status(500).json({
            result: 0,
            message: 'Error getting user by ID',
            error: error.message,
        });
    }
};

const deleteUser = async (req, res) => {
    try {
        const userId = req.params.id;

        const getUserQuery = `
            SELECT * FROM "user" WHERE id = @userId
        `;
        const userData = await executeQuery(getUserQuery, { userId });

        if (userData.length === 0) {
            return res.status(404).json({
                result: 3,
                error: 'User not found',
                data: []
            });
        }

        const deleteQuery = `
            DELETE FROM "user" WHERE id = @userId
        `;
        const deleteUserResult = await executeQuery(deleteQuery, { userId });

        res.status(200).json({
            result: 1,
            message: 'Delete user successfully',
            data: userId
        });

    } catch (error) {
        console.error('Error deleting user:', error);
        res.status(500).json({
            result: 0,
            message: 'Error deleting user',
            error: error.message,
        });
    }
};

const updateUser = async (req, res) => {
    try {
        const userId = req.params.id;
        const { username, phone, code, email, address } = req.body;

        const checkUserQuery = `SELECT * FROM "user" WHERE id = @userId`;
        const existingUser = await executeQuery(checkUserQuery, { userId });
        console.log(existingUser);

        let phoneExists = false;
        let emailExists = false;
        let codeExists = false;
        let editExists = false;

        for (let i = 0; i < existingUser.length; i++) {
            if (existingUser[i].phone === phone) {
                phoneExists = true;
                break;
            }
            if (existingUser[i].email === email) {
                emailExists = true;
                break;
            }
            if (existingUser[i].code === code) {
                codeExists = true;
                break;
            }
            if (existingUser[i].edit === false) {
                editExists = true;
                break;
            }
        }

        if (!existingUser || existingUser.length === 0) {
            return res.status(404).json({
                result: 3,
                error: 'User not found',
                data: []
            });
        }

        if (!username || !phone || !email || !address || !code) {
            console.log('Missing information. Please provide all required fields.');
            return res.status(400).json({
                result: 2,
                message: 'Missing information. Please provide all required fields.',
                data: []
            });
        } else if (editExists) {
            console.log('The user no longer has permission to edit again');
            return res.status(400).json({
                result: 2,
                message: 'The user no longer has permission to edit again',
                data: []
            })
        }
        else if (phoneExists) {
            console.log('This phone already exists');
            return res.status(400).json({
                result: 2,
                message: 'This phone already exists',
                data: []
            })
        } else if (codeExists) {
            console.log('This code already exists');
            return res.status(400).json({
                result: 2,
                message: 'This code already exists',
                data: []
            })
        } else if (emailExists) {
            console.log('This email already exists');
            return res.status(400).json({
                result: 2,
                message: 'This email already exists',
                data: []
            })
        }

        const updateQuery = `
        UPDATE "user"
        SET username = @username, phone = @phone, code = @code,
            email = @email, address = @address,
            edit = 0, change = 0
        WHERE id = @userId
    `;
        const updateResult = await executeQuery(updateQuery, {
            userId,
            username,
            phone,
            code,
            email,
            address,
        });

        res.status(200).json({
            result: 1,
            message: 'User updated successfully',
            data: {
                id: userId,
                username: username,
                phone: phone,
                code: code,
                email: email,
                address: address,
            }
        });
    } catch (error) {
        console.error('Error updating user:', error);
        res.status(500).json({
            result: 0,
            message: 'Error updating user',
            error: error.message,
        });
    }
};

module.exports = {
    getUserData, createUser, getUserById, deleteUser, updateUser,
};