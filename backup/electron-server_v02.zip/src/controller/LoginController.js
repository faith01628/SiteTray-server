const { executeQuery, sql } = require('../database');

const loginAdmin = async (req, res) => {
    try {
        const { username, password } = req.body;
        const query = 'SELECT * FROM "admin" ';
        const admin = await executeQuery(query, { username, password });
        if (admin.length > 0) {
            for (let i = 0; i < admin.length; i++) {
                if (admin[i].username === username && admin[i].password === password) {
                    res.status(200).json({
                        result: 1,
                        message: 'Login successful',
                        data: admin,
                    });
                } else {
                    res.status(404).json({
                        result: 3,
                        message: 'Admin not found or wrong username/password',
                    });
                }
            }
        }
    } catch (error) {
        console.error('Error fetching admin data:', error);
        res.status(500).json({
            result: 0,
            message: 'Error fetching admin data',
            error: error.message,
        });
    }
};


const loginuser = async (req, res) => {
    try {
        const { phone, email } = req.body;
        const query = 'SELECT * FROM "user" ';
        const user = await executeQuery(query, { phone, email });
        if (user.length > 0) {
            for (let i = 0; i < user.length; i++) {
                if (user[i].phone === phone && user[i].email === email) {
                    res.status(200).json({
                        result: 1,
                        message: 'Login successful',
                        data: user,
                    });
                } else {
                    res.status(404).json({
                        result: 3,
                        message: 'user not found or wrong phone/email',
                    });
                }
            }
        }
    } catch (error) {
        console.error('Error fetching user data:', error);
        res.status(500).json({
            result: 0,
            message: 'Error fetching user data',
            error: error.message,
        });
    }
};

module.exports = {
    loginAdmin, loginuser,
};