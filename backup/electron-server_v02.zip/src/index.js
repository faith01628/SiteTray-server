const express = require('express');
const app = express();
const port = 3000;
const bodyParser = require('body-parser');
const { createUser, getUserData, getUserById, deleteUser, updateUser } = require('./controller/UserController');
const { getContentHistory, createContentHistory, deletehistory, deleteMutipleHistory, Pin, unPin } = require('./controller/HistoryadminController');
const { loginAdmin, loginuser } = require('./controller/loginController');
const { getAdmin, getAđminById, updateAdmin } = require('./controller/AdminController');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


app.get('/getUser', getUserData);
app.post('/createUser', createUser);
app.get('/getByUserId/:id', getUserById);
app.delete('/deleteUser/:id', deleteUser);
app.put('/updateUser/:id', updateUser);

app.get('/getContentcopy', getContentHistory);
app.post('/createContentcopy', createContentHistory);
app.delete('/deleteContentcopy/:id', deletehistory);
app.delete('/deleteMutipleByAdmin', deleteMutipleHistory);
app.put('/pin/:id', Pin);
app.put('/unpin/:id', unPin);

app.post('/loginadmin', loginAdmin);
app.post('/loginuser', loginuser);

app.get('/getAdmin', getAdmin);
app.get('/getByAdminId/:id', getAđminById);
app.put('/updateAdmin/:id', updateAdmin);

app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`);
});
