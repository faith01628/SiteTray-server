const { executeQuery, sql } = require('../database');

let lastWinner = null; // In-memory store for the last winner

const gacha = async () => { // Remove (req, res) arguments
    try {
        const query = 'SELECT * FROM "account" WHERE role = 0';
        const users = await executeQuery(query);

        if (users.length === 0) {
            throw new Error('No users found');
        }

        const winprizeQuery = 'SELECT accountid FROM "winprize"';
        const winprizeUsers = await executeQuery(winprizeQuery);
        const winprizeUserIds = winprizeUsers.map(user => user.accountid);

        const eligibleUsers = users.filter(user => !winprizeUserIds.includes(user.id));

        if (eligibleUsers.length === 0) {
            throw new Error('No eligible users for gacha');
        }

        const randomUser = eligibleUsers[Math.floor(Math.random() * eligibleUsers.length)];

        const insertQuery = 'INSERT INTO "winprize" (accountid, winprize) VALUES (@accountid, 1)';
        await executeQuery(insertQuery, { accountid: randomUser.id });

        lastWinner = {
            accountid: randomUser.id,
            winprize: 1,
            code: randomUser.code,
            username: randomUser.username,
            email: randomUser.email,
            phone: randomUser.phone
        };

        return lastWinner; // Return the last winner instead of res.status().json()
    } catch (error) {
        console.error('Error during gacha:', error);
        throw error; // Throw error instead of returning res.status().json()
    }
};

const viewGacha = async (req, res) => {
    try {
        if (!lastWinner) {
            return res.status(404).json({
                result: 3,
                message: 'No winner found',
            });
        }

        return res.status(200).json({
            result: 1,
            message: 'Last winner fetched successfully',
            data: lastWinner,
        });
    } catch (error) {
        console.error('Error during viewGacha:', error);
        return res.status(500).json({
            result: 0,
            message: 'Error during viewGacha',
            error: error.message,
        });
    }
};

const deleteUserGacha = async (req, res) => {
    try {
        const Id = req.params.id;;
        const deleteQuery = 'DELETE FROM winprize WHERE id = @Id';
        await executeQuery(deleteQuery, { id: Id });
        return res.status(200).json({
            result: 1,
            message: 'Last winner deleted successfully',
            data: Id,
        });
    } catch (error) {
        console.error('Error during deleteUserGacha:', error);
        return res.status(500).json({
            result: 0,
            message: 'Error during deleteUserGacha',
            error: error.message,
        });
    }
};

const deleteMultipleGacha = async (req, res) => {
    try {
        await executeQuery('DELETE FROM winprize');
        return res.status(200).json({
            result: 1,
            message: 'All winners deleted successfully',
        });
    } catch (error) {
        console.error('Error during deleteMultipleGacha:', error);
        return res.status(500).json({
            result: 0,
            message: 'Error during deleteMultipleGacha',
            error: error.message,
        });
    }
};

module.exports = { gacha, viewGacha, deleteUserGacha, deleteMultipleGacha };
