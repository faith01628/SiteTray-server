const express = require('express');
const router = express.Router();
const { executeQuery, sql } = require('../database');

const getUserData = async (req, res) => {
    try {
        const query = 'SELECT * FROM "account"';
        const userData = await executeQuery(query);

        res.status(200).json({
            result: 1,
            message: 'Get user data successfully',
            data: userData,
        });
    } catch (error) {
        console.error('Error fetching user data:', error);
        res.status(500).json({
            result: 0,
            message: 'Error fetching user data',
            error: error.message,
        });
    }
};

const createUser = async (req, res) => {
    try {
        const { username, phone, email, address } = req.body;

        // Generate a unique code
        const generateCode = () => {
            const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
            let randomString = '';
            for (let i = 0; i < 8; i++) {
                randomString += characters.charAt(Math.floor(Math.random() * characters.length));
            }
            return randomString;
        };

        let code;
        let codeExists = true;

        // Ensure the generated code is unique
        while (codeExists) {
            code = generateCode();
            const checkCodeQuery = 'SELECT * FROM "account" WHERE code = @code';
            const existingCode = await executeQuery(checkCodeQuery, { code });
            if (existingCode.length === 0) {
                codeExists = false;
            }
        }

        const checkUserQuery = 'SELECT * FROM "account"';
        const existingUser = await executeQuery(checkUserQuery);

        let phoneExists = false;
        let emailExists = false;

        for (let user of existingUser) {
            if (user.phone === phone) {
                phoneExists = true;
                break;
            }
            if (user.email === email) {
                emailExists = true;
                break;
            }
        }

        if (!username || !phone || !email || !address) {
            return res.status(400).json({
                result: 2,
                message: 'Missing information. Please provide all required fields.',
            });
        } else if (emailExists) {
            return res.status(400).json({
                result: 2,
                message: 'This email already exists',
            });
        } else if (phoneExists) {
            return res.status(400).json({
                result: 2,
                message: 'This phone already exists',
            });
        } else {
            const query = `
                INSERT INTO "account" (username, phone, email, address, code, role, edit, ungacha)
                OUTPUT inserted.id
                VALUES (@username, @phone, @email, @address, @code, 0, 1, 0)
            `;

            const result = await executeQuery(query, { username, phone, email, address, code });

            const newUserId = result[0].id;

            // Lấy các đoạn chat mặc định
            const getChatQuery = 'SELECT * FROM "groupchat"';
            const defaultChats = await executeQuery(getChatQuery);

            // Chèn các đoạn chat mặc định vào bảng chat_user
            for (let chat of defaultChats) {
                const insertChatQuery = `
                    INSERT INTO groupchatuser (accountid, name, link, img)
                    VALUES (@accountid, @name, @link, @img)
                `;
                await executeQuery(insertChatQuery, {
                    accountid: newUserId,
                    name: chat.name,
                    link: chat.link,
                    img: chat.img // Assuming img is a field in the chat table
                });
            }

            res.status(201).json({
                result: 1,
                message: 'User created successfully',
                data: { id: newUserId, username, phone, email, address, code },
            });
        }
    } catch (error) {
        console.error('Error creating user:', error);
        res.status(500).json({
            result: 0,
            message: 'Error creating user',
            error: error.message,
        });
    }
};

const getUserById = async (req, res) => {
    try {
        const userId = req.params.id;

        const query = 'SELECT * FROM "account" WHERE id = @userId';
        const userData = await executeQuery(query, { userId });

        if (userData.length > 0) {
            res.status(200).json({
                result: 1,
                message: 'Get user by ID successfully',
                data: userData,
            });
        } else {
            res.status(404).json({
                result: 3,
                message: 'User not found',
            });
        }
    } catch (error) {
        console.error('Error getting user by ID:', error);
        res.status(500).json({
            result: 0,
            message: 'Error getting user by ID',
            error: error.message,
        });
    }
};

const deleteUser = async (req, res) => {
    try {
        const userId = req.params.id;

        const getUserQuery = 'SELECT * FROM "account" WHERE id = @userId';
        const userData = await executeQuery(getUserQuery, { userId });

        if (userData.length === 0) {
            return res.status(404).json({
                result: 3,
                message: 'User not found',
            });
        }

        const checktokenQuery = 'SELECT * FROM "token" WHERE accountid = @userId';
        const existingToken = await executeQuery(checktokenQuery, { userId });
        const deleteTokenQuery = 'DELETE FROM "token" WHERE accountid = @userId';
        await executeQuery(deleteTokenQuery, { userId });


        const checkUserQuery = 'SELECT * FROM "history" WHERE accountid = @userId';
        const existingUser = await executeQuery(checkUserQuery, { userId });
        const deleteHistoryQuery = 'DELETE FROM "history" WHERE accountid = @userId';
        await executeQuery(deleteHistoryQuery, { userId });


        const deleteQuery = 'DELETE FROM "account" WHERE id = @userId';
        await executeQuery(deleteQuery, { userId });

        res.status(200).json({
            result: 1,
            message: 'Delete user successfully',
        });
    } catch (error) {
        console.error('Error deleting user:', error);
        res.status(500).json({
            result: 0,
            message: 'Error deleting user',
            error: error.message,
        });
    }
};

const deleteSignup = async (req, res) => {
    try {
        const userId = req.params.id;

        const getUserQuery = 'SELECT * FROM "account" WHERE id = @userId';
        const userData = await executeQuery(getUserQuery, { userId });

        if (userData.length === 0) {
            return res.status(404).json({
                result: 3,
                message: 'User not found',
            });
        }

        const deleteQuery = 'DELETE FROM "account" WHERE id = @userId';
        await executeQuery(deleteQuery, { userId });

        res.status(200).json({
            result: 1,
            message: 'Delete user successfully',
        });
    } catch (error) {
        console.error('Error deleting user:', error);
        res.status(500).json({
            result: 0,
            message: 'Error deleting user',
            error: error.message,
        });
    }
};

const updateUser = async (req, res) => {
    try {
        const userId = req.params.id;
        const { username, phone, code, email, address } = req.body;

        const checkUserQuery = 'SELECT * FROM "account" WHERE id = @userId';
        const existingUser = await executeQuery(checkUserQuery, { userId });

        const query = 'SELECT * FROM "account"';
        const userData = await executeQuery(query);

        let phoneExists = false;
        let emailExists = false;
        let codeExists = false;
        let editExists = false;

        for (let user of existingUser) {
            if (user.id === userId) {
                if (user.phone === phone && user.email === email) {
                    phoneExists = false;
                    emailExists = false;
                    break;
                }
                if (user.code === code) {
                    codeExists = true;
                }
            } else {
                for (let user of userData) {
                    if (user.id === userId) {
                        continue; // Skip the user being edited
                    }

                    if (user.code === code) {
                        codeExists = true;
                    }
                    if (user.phone === phone) {
                        phoneExists = true;
                    }
                    if (user.email === email) {
                        emailExists = true;
                    }

                    // If all conflicts are found, no need to check further
                    if (phoneExists && emailExists && codeExists) {
                        break;
                    }
                }
            }
        }


        if (!existingUser || existingUser.length === 0) {
            return res.status(404).json({
                result: 3,
                message: 'User not found',
            });
        }

        if (!username || !phone || !email || !address || !code) {
            return res.status(400).json({
                result: 2,
                message: 'Missing information. Please provide all required fields.',
            });
        } else if (editExists) {
            return res.status(400).json({
                result: 2,
                message: 'The user no longer has permission to edit again',
            });
        } else if (phoneExists) {
            return res.status(400).json({
                result: 2,
                message: 'This phone already exists',
            });
        } else if (codeExists) {
            return res.status(400).json({
                result: 2,
                message: 'This code already exists',
            });
        } else if (emailExists) {
            return res.status(400).json({
                result: 2,
                message: 'This email already exists',
            });
        }

        const updateQuery = `
            UPDATE "account"
            SET username = @username, phone = @phone, code = @code,
                email = @email, address = @address,
                role = 0, edit = 0, ungacha = 0
            WHERE id = @userId
        `;
        await executeQuery(updateQuery, {
            userId,
            username,
            phone,
            code,
            email,
            address,
        });

        res.status(200).json({
            result: 1,
            message: 'User updated successfully',
            data: { id: userId, username, phone, code, email, address },
        });
    } catch (error) {
        console.error('Error updating user:', error);
        res.status(500).json({
            result: 0,
            message: 'Error updating user',
            error: error.message,
        });
    }
};

const updateAdmin = async (req, res) => {
    try {
        const userId = req.params.id;
        const { username, phone, code, email, address, edit } = req.body;

        console.log(userId, username, phone, code, email, address, edit);

        const checkUserQuery = 'SELECT * FROM "account" WHERE id = @userId';
        const existingUser = await executeQuery(checkUserQuery, { userId });

        let phoneExists = false;
        let emailExists = false;
        let codeExists = false;

        for (let user of existingUser) {
            if (user.phone === phone) {
                phoneExists = true;
                break;
            }
            if (user.email === email) {
                emailExists = true;
                break;
            }
            if (user.code === code) {
                codeExists = true;
                break;
            }
        }

        if (!existingUser || existingUser.length === 0) {
            return res.status(404).json({
                result: 3,
                message: 'User not found',
            });
        }

        if (!username || !phone || !email || !address || !code) {
            return res.status(400).json({
                result: 2,
                message: 'Missing information. Please provide all required fields.',
            });
        } else if (phoneExists) {
            return res.status(400).json({
                result: 2,
                message: 'This phone already exists',
            });
        } else if (codeExists) {
            return res.status(400).json({
                result: 2,
                message: 'This code already exists',
            });
        } else if (emailExists) {
            return res.status(400).json({
                result: 2,
                message: 'This email already exists',
            });
        }

        const updateQuery = `
            UPDATE "account"
            SET username = @username, phone = @phone, code = @code,
                email = @email, address = @address,
                role = 0, edit = @edit, ungacha = 0
            WHERE id = @userId
        `;
        await executeQuery(updateQuery, {
            userId,
            username,
            phone,
            code,
            email,
            address,
            edit,
        });

        res.status(200).json({
            result: 1,
            message: 'User updated successfully',
            data: { id: userId, username, phone, code, email, address },
        });
    } catch (error) {
        console.error('Error updating user:', error);
        res.status(500).json({
            result: 0,
            message: 'Error updating user',
            error: error.message,
        });
    }
};

const updateSignup = async (req, res) => {
    try {
        const userId = req.params.id;
        const { username, phone, code, email, address, edit } = req.body;

        const checkUserQuery = 'SELECT * FROM "account" WHERE id = @userId';
        const existingUser = await executeQuery(checkUserQuery, { userId });

        // let phoneExists = false;
        // let emailExists = false;
        // let codeExists = false;

        // for (let user of existingUser) {
        //     if (user.phone === phone) {
        //         phoneExists = true;
        //         break;
        //     }
        //     if (user.email === email) {
        //         emailExists = true;
        //         break;
        //     }
        //     if (user.code === code) {
        //         codeExists = true;
        //         break;
        //     }
        // }

        if (!existingUser || existingUser.length === 0) {
            return res.status(404).json({
                result: 3,
                message: 'User not found',
            });
        }

        if (!username || !phone || !email || !address || !code) {
            return res.status(400).json({
                result: 2,
                message: 'Missing information. Please provide all required fields.',
            });
        }
        // else if (phoneExists) {
        //     return res.status(400).json({
        //         result: 2,
        //         message: 'This phone already exists',
        //     });
        // } else if (codeExists) {
        //     return res.status(400).json({
        //         result: 2,
        //         message: 'This code already exists',
        //     });
        // } else if (emailExists) {
        //     return res.status(400).json({
        //         result: 2,
        //         message: 'This email already exists',
        //     });
        // }

        const updateQuery = `
            UPDATE "account"
            SET username = @username, phone = @phone, code = @code,
                email = @email, address = @address,
                role = 0, edit = 1, ungacha = 0
            WHERE id = @userId
        `;
        await executeQuery(updateQuery, {
            userId,
            username,
            phone,
            code,
            email,
            address,
            edit,
        });

        res.status(200).json({
            result: 1,
            message: 'User updated successfully',
            data: { id: userId, username, phone, code, email, address },
        });
    } catch (error) {
        console.error('Error updating user:', error);
        res.status(500).json({
            result: 0,
            message: 'Error updating user',
            error: error.message,
        });
    }
};

const ungacha = async (req, res) => {
    try {
        const userId = req.params.id;
        const { ungacha } = req.body;
        const checkUserQuery = 'SELECT * FROM "account" WHERE id = @userId';
        const existingUser = await executeQuery(checkUserQuery, { userId });

        if (!existingUser || existingUser.length === 0) {
            return res.status(404).json({
                result: 3,
                message: 'User not found',
            });
        }

        const updateQuery = `
        UPDATE "account"
        SET  ungacha = 1
        WHERE id = @userId
    `;
        await executeQuery(updateQuery, {
            userId,
            ungacha,
        });

        res.status(200).json({
            result: 1,
            message: 'User updated successfully',
            data: { id: userId, ungacha: ungacha },
        });

    } catch (error) {
        console.error('Error updating user:', error);
        res.status(500).json({
            result: 0,
            message: 'Error updating user',
            error: error.message,
        });
    }
};

const unLockgacha = async (req, res) => {
    try {
        const userId = req.params.id;
        const { ungacha } = req.body;
        const checkUserQuery = 'SELECT * FROM "account" WHERE id = @userId';
        const existingUser = await executeQuery(checkUserQuery, { userId });

        if (!existingUser || existingUser.length === 0) {
            return res.status(404).json({
                result: 3,
                message: 'User not found',
            });
        }

        const updateQuery = `
        UPDATE "account"
        SET  ungacha = 0
        WHERE id = @userId
    `;
        await executeQuery(updateQuery, {
            userId,
            ungacha,
        });

        res.status(200).json({
            result: 1,
            message: 'User updated successfully',
            data: { id: userId, ungacha: ungacha },
        });

    } catch (error) {
        console.error('Error updating user:', error);
        res.status(500).json({
            result: 0,
            message: 'Error updating user',
            error: error.message,
        });
    }
};

module.exports = {
    getUserData,
    createUser,
    getUserById,
    deleteUser,
    deleteSignup,
    updateUser,
    updateAdmin,
    updateSignup,
    ungacha,
    unLockgacha,
};
