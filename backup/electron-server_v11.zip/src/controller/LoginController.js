const express = require('express');
const router = express.Router();
const { generateToken } = require('../auth');
const { executeQuery, sql } = require('../database');

async function saveOrUpdateToken(accountId, token) {
    const checkQuery = `SELECT * FROM token WHERE accountid = @accountid`;
    const checkParams = { accountid: accountId };
    const existingToken = await executeQuery(checkQuery, checkParams);

    if (existingToken.length === 0) {
        const insertQuery = `
            INSERT INTO token (accountid, token, status)
            VALUES (@accountid, @token, 1)
        `;
        await executeQuery(insertQuery, { accountid: accountId, token });
    } else {
        const updateQuery = `
            UPDATE token
            SET token = @token, status = 1
            WHERE accountid = @accountid
        `;
        await executeQuery(updateQuery, { accountid: accountId, token });
    }
}

const login = async (req, res) => {
    try {
        const { email, password, phone } = req.body;


        console.log(req.body)

        if (!email) {
            return res.status(400).json({
                result: 2,
                message: 'Missing required fields: email',
            });
        }

        const query = 'SELECT * FROM "account" WHERE email = @email';
        const params = { email };
        const user = await executeQuery(query, params);

        if (user.length === 0) {
            return res.status(404).json({
                result: 3,
                message: 'User not found',
            });
        }

        const foundUser = user[0];

        if (foundUser.role) {  // Check if the user is an admin
            if (!password) {
                return res.status(400).json({
                    result: 2,
                    message: 'Missing required fields: password',
                });
            }

            if (foundUser.password === password) {
                const token = generateToken(foundUser);
                await saveOrUpdateToken(foundUser.id, token);
                return res.status(200).json({
                    result: 1,
                    message: 'Admin login successful',
                    data: { user: foundUser, token },
                });
            } else {
                return res.status(404).json({
                    result: 3,
                    message: 'Wrong password for admin',
                });
            }
        } else {  // The user is a regular user
            if (!phone) {
                return res.status(400).json({
                    result: 2,
                    message: 'Missing required fields: phone',
                });
            }

            if (foundUser.phone === phone) {
                const token = generateToken(foundUser);
                await saveOrUpdateToken(foundUser.id, token);
                return res.status(200).json({
                    result: 1,
                    message: 'User login successful',
                    data: { user: foundUser, token },
                });
            } else {
                return res.status(404).json({
                    result: 3,
                    message: 'Wrong phone for user',
                });
            }
        }
    } catch (error) {
        console.error('Error during login:', error);
        res.status(500).json({
            result: 0,
            message: 'Error during login',
            error: error.message,
        });
    }
};

const checkrole = async (req, res) => {
    try {
        const { email } = req.body;

        if (!email) {
            return res.status(400).json({
                result: 2,
                message: 'Missing required fields: email',
            });
        }

        const query = 'SELECT role FROM "account" WHERE email = @email';
        const params = { email };
        const user = await executeQuery(query, params);

        if (user.length === 0) {
            return res.status(404).json({
                result: 3,
                message: 'User not found',
            });
        }

        const foundUser = user[0];
        const isAdmin = foundUser.role ? true : false;

        return res.status(200).json({
            result: 1,
            isAdmin: isAdmin,
        });
    } catch (error) {
        console.error('Error during check role:', error);
        res.status(500).json({
            result: 0,
            message: 'Error during check role',
            error: error.message,
        });
    }
}

module.exports = {
    login, checkrole
};
