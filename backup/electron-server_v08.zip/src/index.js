const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const http = require('http');
const socketIo = require('socket.io'); // Import socket.io

const app = express(); // Define app before using it
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

const { createUser, getUserData, getUserById, deleteUser, deleteSignup, updateUser, updateAdmin, updateSignup } = require('./controller/AccountController');
const { getContentHistory, getHistoryById, createContentHistory, deletehistory, deleteMutipleHistory, Pin, unPin } = require('./controller/HistoryController');
const { getWinPrize } = require('./controller/WinprizeController');
const { gacha, viewGacha } = require('./controller/GachaController');
const { login, checkrole } = require('./controller/LoginController');
const { authenticateAdminToken, authenticateBothTokens } = require('./auth');

const port = 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());

app.use((req, res, next) => {
    req.io = io;
    next();
});

// Define routes
app.get('/getUser', authenticateAdminToken, getUserData);
app.post('/createUser', createUser);
app.get('/getByUserId/:id', getUserById);
app.delete('/deleteUser/:id', authenticateAdminToken, deleteUser);
app.delete('/deleteSignup/:id', deleteSignup);
app.put('/updateUser/:id', authenticateBothTokens, updateUser);
app.put('/updateAdmin/:id', authenticateAdminToken, updateAdmin);
app.put('/updatesignup/:id', updateSignup);

app.post('/gacha', gacha);
app.get('/viewgacha', viewGacha);

app.get('/getWinPrize', getWinPrize);

app.get('/getContentcopy', authenticateAdminToken, getContentHistory);
app.post('/getContentById', authenticateBothTokens, getHistoryById);
app.post('/createContentcopy', authenticateBothTokens, createContentHistory);
app.delete('/deleteContentcopy/:id', authenticateBothTokens, deletehistory);
app.delete('/deleteMutipleByAdmin', authenticateBothTokens, deleteMutipleHistory);
app.put('/pin/:id', authenticateBothTokens, Pin);
app.put('/unpin/:id', authenticateBothTokens, unPin);

app.post('/login', login);
app.get('/checkrole', checkrole);

// Handle socket connections
io.on('connection', (socket) => {
    console.log('A user connected');

    socket.on('disconnect', () => {
        console.log('User disconnected');
    });

    socket.on('message', (message) => {
        console.log('Message received:', message);
        io.emit('message', message); // Broadcast the message to all clients
    });

    socket.on('gacha', async () => {
        try {
            const user = await viewGacha();
            io.emit('gachaResult', { username: user.username, code: user.code, phone: user.phone });
        } catch (error) {
            socket.emit('error', 'An error occurred while performing gacha');
        }
    });
});

server.listen(port, () => {
    console.log(`Server listening at http://localhost:${port}`);
});