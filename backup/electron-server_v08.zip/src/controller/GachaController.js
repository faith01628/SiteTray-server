const express = require('express');
const router = express.Router();
const { executeQuery, sql } = require('../database');

let lastWinner = null; // In-memory store for the last winner

const gacha = async (req, res) => {
    try {
        // Lấy tất cả người dùng ngoại trừ admin
        const query = 'SELECT * FROM "account" WHERE role = 0';
        const users = await executeQuery(query);

        if (users.length === 0) {
            return res.status(404).json({
                result: 3,
                message: 'No users found',
            });
        }

        // Lấy danh sách người dùng đã trúng thưởng
        const winprizeQuery = 'SELECT accountid FROM "winprize"';
        const winprizeUsers = await executeQuery(winprizeQuery);
        const winprizeUserIds = winprizeUsers.map(user => user.accountid);

        // Lọc ra danh sách người dùng chưa trúng thưởng
        const eligibleUsers = users.filter(user => !winprizeUserIds.includes(user.id));

        if (eligibleUsers.length === 0) {
            return res.status(400).json({
                result: 2,
                message: 'No eligible users for gacha',
            });
        }

        // Lấy ngẫu nhiên một người dùng chưa trúng thưởng
        const randomUser = eligibleUsers[Math.floor(Math.random() * eligibleUsers.length)];

        // Thêm người dùng vào bảng winprize
        const insertQuery = 'INSERT INTO "winprize" (accountid, winprize) VALUES (@accountid, 1)';
        await executeQuery(insertQuery, { accountid: randomUser.id });

        return res.status(200).json({
            result: 1,
            message: 'User added to winprize successfully',
            data: {
                accountid: randomUser.id,
                winprize: 1,
                code: randomUser.code,
                username: randomUser.username,
                email: randomUser.email,
                phone: randomUser.phone
            }
        });
    } catch (error) {
        console.error('Error during gacha:', error);
        return res.status(500).json({
            result: 0,
            message: 'Error during gacha',
            error: error.message,
        });
    }
};

const viewGacha = async (req, res) => {
    try {
        if (!lastWinner) {
            return res.status(404).json({
                result: 3,
                message: 'No winner found',
            });
        }

        return res.status(200).json({
            result: 1,
            message: 'Last winner fetched successfully',
            data: lastWinner,
        });
    } catch (error) {
        console.error('Error during viewGacha:', error);
        return res.status(500).json({
            result: 0,
            message: 'Error during viewGacha',
            error: error.message,
        });
    }
};

module.exports = { gacha, viewGacha };