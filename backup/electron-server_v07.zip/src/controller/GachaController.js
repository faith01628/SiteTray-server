const express = require('express');
const router = express.Router();
const { executeQuery, sql } = require('../database');

let lastWinner = null; // In-memory store for the last winner

const gacha = async (req, res) => {
    try {
        const query = 'SELECT * FROM "account" WHERE role = 0';
        const users = await executeQuery(query);

        if (users.length === 0) {
            return res.status(404).json({
                result: 3,
                message: 'No users found',
            });
        }

        const randomUser = users[Math.floor(Math.random() * users.length)];

        const checkQuery = 'SELECT * FROM "winprize" WHERE accountid = @accountid';
        const existingWinPrize = await executeQuery(checkQuery, { accountid: randomUser.id });

        if (existingWinPrize.length > 0) {
            return res.status(400).json({
                result: 2,
                message: 'User already exists in winprize',
            });
        }

        const insertQuery = 'INSERT INTO "winprize" (accountid, winprize) VALUES (@accountid, 1)';
        await executeQuery(insertQuery, { accountid: randomUser.id });

        // Store the winning user in the in-memory store
        lastWinner = { accountid: randomUser.id, username: randomUser.username };

        return res.status(200).json({
            result: 1,
            message: 'User added to winprize successfully',
            data: { accountid: randomUser.id, winprize: 1 },
        });
    } catch (error) {
        console.error('Error during gacha:', error);
        return res.status(500).json({
            result: 0,
            message: 'Error during gacha',
            error: error.message,
        });
    }
};

const viewGacha = async (req, res) => {
    try {
        if (!lastWinner) {
            return res.status(404).json({
                result: 3,
                message: 'No winner found',
            });
        }

        return res.status(200).json({
            result: 1,
            message: 'Last winner fetched successfully',
            data: lastWinner,
        });
    } catch (error) {
        console.error('Error during viewGacha:', error);
        return res.status(500).json({
            result: 0,
            message: 'Error during viewGacha',
            error: error.message,
        });
    }
};

module.exports = { gacha, viewGacha };