const { executeQuery, sql } = require('../database');

const login = async (req, res) => {
    try {
        const { email, password, phone } = req.body;

        if (!email) {
            return res.status(400).json({
                result: 2,
                message: 'Missing required fields: email',
            });
        }

        const query = 'SELECT * FROM "account" WHERE email = @email';
        const params = { email };
        const user = await executeQuery(query, params);

        if (user.length === 0) {
            return res.status(404).json({
                result: 3,
                message: 'User not found',
            });
        }

        const foundUser = user[0];

        if (foundUser.role) {  // Check if the user is an admin
            if (!password) {
                return res.status(400).json({
                    result: 2,
                    message: 'Missing required fields: password',
                });
            }

            if (foundUser.password === password) {
                return res.status(200).json({
                    result: 1,
                    message: 'Admin login successful',
                    data: foundUser,
                });
            } else {
                return res.status(404).json({
                    result: 3,
                    message: 'Wrong password for admin',
                });
            }
        } else {  // The user is a regular user
            if (!phone) {
                return res.status(400).json({
                    result: 2,
                    message: 'Missing required fields: phone',
                });
            }

            if (foundUser.phone === phone) {
                return res.status(200).json({
                    result: 1,
                    message: 'User login successful',
                    data: foundUser,
                });
            } else {
                return res.status(404).json({
                    result: 3,
                    message: 'Wrong phone for user',
                });
            }
        }
    } catch (error) {
        console.error('Error during login:', error);
        res.status(500).json({
            result: 0,
            message: 'Error during login',
            error: error.message,
        });
    }
};

const checkrole = async (req, res) => {
    try {
        const { email } = req.body;

        if (!email) {
            return res.status(400).json({
                result: 2,
                message: 'Missing required fields: email',
            });
        }

        const query = 'SELECT role FROM "account" WHERE email = @email';
        const params = { email };
        const user = await executeQuery(query, params);

        if (user.length === 0) {
            return res.status(404).json({
                result: 3,
                message: 'User not found',
            });
        }

        const foundUser = user[0];
        const isAdmin = foundUser.role ? true : false;

        return res.status(200).json({
            result: 1,
            isAdmin: isAdmin,
        });
    } catch (error) {
        console.error('Error during check role:', error);
        res.status(500).json({
            result: 0,
            message: 'Error during check role',
            error: error.message,
        });
    }
}

module.exports = {
    login, checkrole
};
