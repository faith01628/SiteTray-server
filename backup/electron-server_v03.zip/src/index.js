const express = require('express');
const app = express();
const port = 3000;
const bodyParser = require('body-parser');
const { createUser, getUserData, getUserById, deleteUser, updateUser, updateAdmin } = require('./controller/AccountController');
const { getContentHistory, createContentHistory, deletehistory, deleteMutipleHistory, Pin, unPin } = require('./controller/HistoryadminController');
const { login, checkrole } = require('./controller/LoginController');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


app.get('/getUser', getUserData);
app.post('/createUser', createUser);
app.get('/getByUserId/:id', getUserById);
app.delete('/deleteUser/:id', deleteUser);
app.put('/updateUser/:id', updateUser);
app.put('/updateAdmin/:id', updateAdmin);

app.get('/getContentcopy', getContentHistory);
app.post('/createContentcopy', createContentHistory);
app.delete('/deleteContentcopy/:id', deletehistory);
app.delete('/deleteMutipleByAdmin', deleteMutipleHistory);
app.put('/pin/:id', Pin);
app.put('/unpin/:id', unPin);

app.post('/login', login);
app.get('/checkrole', checkrole);


app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`);
});
