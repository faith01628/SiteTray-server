const sql = require('mssql');

const config = {
    server: 'localhost',
    user: 'sa',
    password: '123',
    database: 'gacha',
    options: {
        encrypt: false, // Nếu không sử dụng SSL, đặt là false
        enableArithAbort: true, // Đặt là true để tránh lỗi khi dùng với các phiên bản mới hơn của SQL Server
    }
};
// const connectDB = async () => {
//     try {
//         await sql.connect(config);
//         console.log('Connected to MSSQL database');
//     } catch (err) {
//         console.error('Error connecting to MSSQL:', err);
//     }
// };

const poolPromise = new sql.ConnectionPool(config)
    .connect()
    .then(pool => {
        console.log('Connected to MSSQL database');
        return pool;
    })
    .catch(err => console.error('Error connecting to MSSQL:', err));

const executeQuery = async (query, params = {}) => {
    try {
        const pool = await poolPromise;
        const request = pool.request();

        for (const [key, value] of Object.entries(params)) {
            request.input(key, value);
        }

        const result = await request.query(query);
        return result.recordset;
    } catch (err) {
        console.error('Error executing query:', err);
        throw err;
    }
};

module.exports = {
    executeQuery,
    sql,
};
