const express = require('express');
const app = express();
const port = 3000;
const bodyParser = require('body-parser');
const { createUser, getUserData, getUserById, deleteUser, updateUser, updateAdmin } = require('./controller/AccountController');
const { getContentHistory, createContentHistory, deletehistory, deleteMutipleHistory, Pin, unPin } = require('./controller/HistoryController');
const { login, checkrole } = require('./controller/LoginController');
const { authenticateAdminToken, authenticateBothTokens, authenticateUserToken } = require('./auth');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


app.get('/getUser', authenticateAdminToken, getUserData);
app.post('/createUser', authenticateBothTokens, createUser);
app.get('/getByUserId/:id', authenticateBothTokens, getUserById);
app.delete('/deleteUser/:id', authenticateAdminToken, deleteUser);
app.put('/updateUser/:id', authenticateBothTokens, updateUser);
app.put('/updateAdmin/:id', authenticateAdminToken, updateAdmin);

app.get('/getContentcopy', authenticateBothTokens, getContentHistory);
app.post('/createContentcopy', authenticateBothTokens, createContentHistory);
app.delete('/deleteContentcopy/:id', authenticateBothTokens, deletehistory);
app.delete('/deleteMutipleByAdmin', authenticateBothTokens, deleteMutipleHistory);
app.put('/pin/:id', authenticateBothTokens, Pin);
app.put('/unpin/:id', authenticateBothTokens, unPin);

app.post('/login', login);
app.get('/checkrole', checkrole);


app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`);
});
