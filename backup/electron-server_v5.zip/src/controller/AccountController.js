const express = require('express');
const router = express.Router();
const { executeQuery, sql } = require('../database');

const login = async (req, res) => {
    try {
        const { email, password, phone } = req.body;

        if (!email) {
            return res.status(400).json({
                result: 2,
                message: 'Missing required fields: email',
            });
        }

        const query = 'SELECT * FROM "account" WHERE email = @email';
        const params = { email };
        const user = await executeQuery(query, params);

        if (user.length === 0) {
            return res.status(404).json({
                result: 3,
                message: 'User not found',
            });
        }

        const foundUser = user[0];

        if (foundUser.role) {
            if (!password) {
                return res.status(400).json({
                    result: 2,
                    message: 'Missing required fields: password',
                });
            }

            if (foundUser.password === password) {
                return res.status(200).json({
                    result: 1,
                    message: 'Admin login successful',
                    data: foundUser,
                });
            } else {
                return res.status(404).json({
                    result: 3,
                    message: 'Wrong password for admin',
                });
            }
        } else {
            if (!phone) {
                return res.status(400).json({
                    result: 2,
                    message: 'Missing required fields: phone',
                });
            }

            if (foundUser.phone === phone) {
                return res.status(200).json({
                    result: 1,
                    message: 'User login successful',
                    data: foundUser,
                });
            } else {
                return res.status(404).json({
                    result: 3,
                    message: 'Wrong phone for user',
                });
            }
        }
    } catch (error) {
        console.error('Error during login:', error);
        res.status(500).json({
            result: 0,
            message: 'Error during login',
            error: error.message,
        });
    }
};

const checkrole = async (req, res) => {
    try {
        const { email } = req.body;

        if (!email) {
            return res.status(400).json({
                result: 2,
                message: 'Missing required fields: email',
            });
        }

        const query = 'SELECT role FROM "account" WHERE email = @email';
        const params = { email };
        const user = await executeQuery(query, params);

        if (user.length === 0) {
            return res.status(404).json({
                result: 3,
                message: 'User not found',
            });
        }

        const foundUser = user[0];
        const isAdmin = foundUser.role ? true : false;

        return res.status(200).json({
            result: 1,
            isAdmin: isAdmin,
        });
    } catch (error) {
        console.error('Error during check role:', error);
        res.status(500).json({
            result: 0,
            message: 'Error during check role',
            error: error.message,
        });
    }
};

const getUserData = async (req, res) => {
    try {
        const query = 'SELECT * FROM "account"';
        const userData = await executeQuery(query);

        res.status(200).json({
            result: 1,
            message: 'Get user data successfully',
            data: userData,
        });
    } catch (error) {
        console.error('Error fetching user data:', error);
        res.status(500).json({
            result: 0,
            message: 'Error fetching user data',
            error: error.message,
        });
    }
};

const createUser = async (req, res) => {
    try {
        const { username, phone, email, address, code, role } = req.body;

        const checkUserQuery = 'SELECT * FROM "account"';
        const existingUser = await executeQuery(checkUserQuery);

        let phoneExists = false;
        let emailExists = false;
        let codeExists = false;

        for (let user of existingUser) {
            if (user.phone === phone) {
                phoneExists = true;
                break;
            }
            if (user.email === email) {
                emailExists = true;
                break;
            }
            if (user.code === code) {
                codeExists = true;
                break;
            }
        }

        if (!username || !phone || !email || !address || !code) {
            return res.status(400).json({
                result: 2,
                message: 'Missing information. Please provide all required fields.',
            });
        } else if (emailExists) {
            return res.status(400).json({
                result: 2,
                message: 'This email already exists',
            });
        } else if (phoneExists) {
            return res.status(400).json({
                result: 2,
                message: 'This phone already exists',
            });
        } else if (codeExists) {
            return res.status(400).json({
                result: 2,
                message: 'This code already exists',
            });
        } else {
            const query = `
                INSERT INTO "account" (username, phone, email, address, code, role, edit)
                VALUES (@username, @phone, @email, @address, @code, 0, 1)
            `;

            await executeQuery(query, { username, phone, email, address, code });

            res.status(201).json({
                result: 0,
                message: 'User created successfully',
                data: { username, phone, email, address, code },
            });
        }
    } catch (error) {
        console.error('Error creating user:', error);
        res.status(500).json({
            result: 0,
            message: 'Error creating user',
            error: error.message,
        });
    }
};

const getUserById = async (req, res) => {
    try {
        const userId = req.params.id;

        const query = 'SELECT * FROM "account" WHERE id = @userId';
        const userData = await executeQuery(query, { userId });

        if (userData.length > 0) {
            res.status(200).json({
                result: 1,
                message: 'Get user by ID successfully',
                data: userData,
            });
        } else {
            res.status(404).json({
                result: 3,
                message: 'User not found',
            });
        }
    } catch (error) {
        console.error('Error getting user by ID:', error);
        res.status(500).json({
            result: 0,
            message: 'Error getting user by ID',
            error: error.message,
        });
    }
};

const deleteUser = async (req, res) => {
    try {
        const userId = req.params.id;

        const getUserQuery = 'SELECT * FROM "account" WHERE id = @userId';
        const userData = await executeQuery(getUserQuery, { userId });

        if (userData.length === 0) {
            return res.status(404).json({
                result: 3,
                message: 'User not found',
            });
        }

        const deleteQuery = 'DELETE FROM "account" WHERE id = @userId';
        await executeQuery(deleteQuery, { userId });

        res.status(200).json({
            result: 1,
            message: 'Delete user successfully',
        });
    } catch (error) {
        console.error('Error deleting user:', error);
        res.status(500).json({
            result: 0,
            message: 'Error deleting user',
            error: error.message,
        });
    }
};

const updateUser = async (req, res) => {
    try {
        const userId = req.params.id;
        const { username, phone, code, email, address } = req.body;

        const checkUserQuery = 'SELECT * FROM "account" WHERE id = @userId';
        const existingUser = await executeQuery(checkUserQuery, { userId });

        let phoneExists = false;
        let emailExists = false;
        let codeExists = false;
        let editExists = false;

        for (let user of existingUser) {
            if (user.phone === phone) {
                phoneExists = true;
                break;
            }
            if (user.email === email) {
                emailExists = true;
                break;
            }
            if (user.code === code) {
                codeExists = true;
                break;
            }
            if (user.edit === false) {
                editExists = true;
                break;
            }
        }

        if (!existingUser || existingUser.length === 0) {
            return res.status(404).json({
                result: 3,
                message: 'User not found',
            });
        }

        if (!username || !phone || !email || !address || !code) {
            return res.status(400).json({
                result: 2,
                message: 'Missing information. Please provide all required fields.',
            });
        } else if (editExists) {
            return res.status(400).json({
                result: 2,
                message: 'The user no longer has permission to edit again',
            });
        } else if (phoneExists) {
            return res.status(400).json({
                result: 2,
                message: 'This phone already exists',
            });
        } else if (codeExists) {
            return res.status(400).json({
                result: 2,
                message: 'This code already exists',
            });
        } else if (emailExists) {
            return res.status(400).json({
                result: 2,
                message: 'This email already exists',
            });
        }

        const updateQuery = `
            UPDATE "account"
            SET username = @username, phone = @phone, code = @code,
                email = @email, address = @address,
                role = 0, edit = 0
            WHERE id = @userId
        `;
        await executeQuery(updateQuery, {
            userId,
            username,
            phone,
            code,
            email,
            address,
        });

        res.status(200).json({
            result: 1,
            message: 'User updated successfully',
            data: { id: userId, username, phone, code, email, address },
        });
    } catch (error) {
        console.error('Error updating user:', error);
        res.status(500).json({
            result: 0,
            message: 'Error updating user',
            error: error.message,
        });
    }
};

const updateAdmin = async (req, res) => {
    try {
        const userId = req.params.id;
        const { username, phone, code, email, address, edit } = req.body;

        const checkUserQuery = 'SELECT * FROM "account" WHERE id = @userId';
        const existingUser = await executeQuery(checkUserQuery, { userId });

        let phoneExists = false;
        let emailExists = false;
        let codeExists = false;

        for (let user of existingUser) {
            if (user.phone === phone) {
                phoneExists = true;
                break;
            }
            if (user.email === email) {
                emailExists = true;
                break;
            }
            if (user.code === code) {
                codeExists = true;
                break;
            }
        }

        if (!existingUser || existingUser.length === 0) {
            return res.status(404).json({
                result: 3,
                message: 'User not found',
            });
        }

        if (!username || !phone || !email || !address || !code) {
            return res.status(400).json({
                result: 2,
                message: 'Missing information. Please provide all required fields.',
            });
        } else if (phoneExists) {
            return res.status(400).json({
                result: 2,
                message: 'This phone already exists',
            });
        } else if (codeExists) {
            return res.status(400).json({
                result: 2,
                message: 'This code already exists',
            });
        } else if (emailExists) {
            return res.status(400).json({
                result: 2,
                message: 'This email already exists',
            });
        }

        const updateQuery = `
            UPDATE "account"
            SET username = @username, phone = @phone, code = @code,
                email = @email, address = @address,
                role = 0, edit = @edit
            WHERE id = @userId
        `;
        await executeQuery(updateQuery, {
            userId,
            username,
            phone,
            code,
            email,
            address,
            edit,
        });

        res.status(200).json({
            result: 1,
            message: 'User updated successfully',
            data: { id: userId, username, phone, code, email, address },
        });
    } catch (error) {
        console.error('Error updating user:', error);
        res.status(500).json({
            result: 0,
            message: 'Error updating user',
            error: error.message,
        });
    }
};

module.exports = {
    login,
    checkrole,
    getUserData,
    createUser,
    getUserById,
    deleteUser,
    updateUser,
    updateAdmin,
};
