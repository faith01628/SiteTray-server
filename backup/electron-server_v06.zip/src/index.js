const express = require('express');
const cors = require('cors');
const app = express();
const port = 3000;
const bodyParser = require('body-parser');
const { createUser, getUserData, getUserById, deleteUser, deleteSignup, updateUser, updateAdmin, updateSignup } = require('./controller/AccountController');
const { getContentHistory, createContentHistory, deletehistory, deleteMutipleHistory, Pin, unPin } = require('./controller/HistoryController');
const { login, checkrole } = require('./controller/LoginController');
const { authenticateAdminToken, authenticateBothTokens, authenticateUserToken } = require('./auth');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());


app.get('/getUser', authenticateAdminToken, getUserData);
app.post('/createUser', createUser);
app.get('/getByUserId/:id', getUserById);
app.delete('/deleteUser/:id', authenticateAdminToken, deleteUser);
app.delete('/deleteSignup/:id', deleteUser);
app.put('/updateUser/:id', authenticateBothTokens, updateUser);
app.put('/updateAdmin/:id', authenticateAdminToken, updateAdmin);
app.put('/updatesignup/:id', updateSignup);

app.get('/getContentcopy', authenticateBothTokens, getContentHistory);
app.post('/createContentcopy', authenticateBothTokens, createContentHistory);
app.delete('/deleteContentcopy/:id', authenticateBothTokens, deletehistory);
app.delete('/deleteMutipleByAdmin', authenticateBothTokens, deleteMutipleHistory);
app.put('/pin/:id', authenticateBothTokens, Pin);
app.put('/unpin/:id', authenticateBothTokens, unPin);

app.post('/login', login);
app.get('/checkrole', checkrole);


app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`);
});
