const { executeQuery, sql } = require('../database');

const getContentNote = async (req, res) => {
    try {
        const query = 'SELECT * FROM "contentnote"';
        const contentHistory = await executeQuery(query);
        res.status(200).json({
            result: 1,
            message: 'get content contentnote successfully',
            data: contentHistory
        });
    } catch (error) {
        console.error('Error fetching content contentnote:', error);
        res.status(500).json({
            result: 0,
            message: 'Error fetching content contentnote',
            error: error.message
        });
    }
}

const getContentNoteById = async (req, res) => {
    try {
        const { noteid } = req.body;
        const query = 'SELECT * FROM "contentnote" WHERE noteid = @noteid';
        const contentHistory = await executeQuery(query, { noteid: noteid });
        res.status(200).json({
            result: 1,
            message: 'Get content contentnote successfully',
            data: contentHistory
        });
    } catch (error) {
        console.error('Error fetching content contentnote:', error);
        res.status(500).json({
            result: 0,
            message: 'Error fetching content contentnote',
            error: error.message
        });
    }
}
const createContentNote = async (req, res) => {
    try {
        const { noteid, contentnote } = req.body;

        if (!noteid || !contentnote) {
            return res.status(400).json({
                result: 0,
                message: 'Missing required fields',
            });
        }

        const query = `INSERT INTO "contentnote" ( "noteid" , "contentnote", "important", "checksuccess") VALUES ( @noteid, @contentnote , 0, 0)`;
        await executeQuery(query, { noteid: noteid, contentnote: contentnote, important: 0, checksuccess: 0 });
        res.status(200).json({
            result: 1,
            message: 'create content contentnote successfully',
            data: { noteid, contentnote, important: 0 },
        });
    } catch (error) {
        console.error('Error creating content contentnote:', error);
        res.status(500).json({
            result: 0,
            message: 'Error creating content contentnote',
            error: error.message
        });
    }
}

const deleteContentNote = async (req, res) => {
    try {
        const id = req.params.id;
        const query = `DELETE FROM "contentnote" WHERE "id" = @id`;
        await executeQuery(query, { id: id });
        res.status(200).json({
            result: 1,
            message: 'delete content contentnote successfully',
            data: { id },
        });
    } catch (error) {
        console.error('Error deleting content contentnote:', error);
        res.status(500).json({
            result: 0,
            message: 'Error deleting content contentnote',
            error: error.message
        });
    }
}


const updateContent = async (req, res) => {
    try {
        const id = req.params.id;
        const { contentnote } = req.body;
        console.log(contentnote)
        const query = `UPDATE "contentnote" SET "contentnote" = @contentnote WHERE "id" = @id`;
        await executeQuery(query, { contentnote: contentnote, id: id });
        res.status(200).json({
            result: 1,
            message: 'update content contentnote successfully',
            data: { id, contentnote },
        });
    } catch (error) {
        console.error('Error updating content contentnote:', error);
        res.status(500).json({
            result: 0,
            message: 'Error updating content contentnote',
            error: error.message
        });
    }
}

const PinContentNote = async (req, res) => {
    try {
        const id = req.params.id;
        const { important } = req.body;

        const checkHistoryQuery = `SELECT * FROM contentnote WHERE id = @id`;
        const existingHistory = await executeQuery(checkHistoryQuery, { id });
        // console.log(existingHistory);

        if (!existingHistory || existingHistory.length === 0) {
            return res.status(404).json({
                result: 3,
                error: 'User not found',
                data: []
            });
        }

        const updateQuery = `
            UPDATE contentnote
            SET important = 1
            WHERE id = @id
        `;
        const updateResult = await executeQuery(updateQuery, { important, id });

        res.status(200).json({
            result: 1,
            message: 'History updated successfully',
            data: [],
        });
    } catch (error) {
        console.error('Error updating contentnote:', error);
        res.status(500).json({
            result: 0,
            message: 'Error updating contentnote',
            error: error.message,
        });
    }
};

const unPinContentNote = async (req, res) => {
    try {
        const id = req.params.id;
        const { important } = req.body;

        const checkHistoryQuery = `SELECT * FROM contentnote WHERE id = @id`;
        const existingHistory = await executeQuery(checkHistoryQuery, { id });
        // console.log(existingHistory);

        if (!existingHistory || existingHistory.length === 0) {
            return res.status(404).json({
                result: 3,
                error: 'User not found',
                data: []
            });
        }

        const updateQuery = `
            UPDATE contentnote
            SET important = 0
            WHERE id = @id
        `;
        const updateResult = await executeQuery(updateQuery, { important, id });

        res.status(200).json({
            result: 1,
            message: 'History updated successfully',
            data: [],
        });
    } catch (error) {
        console.error('Error updating contentnote:', error);
        res.status(500).json({
            result: 0,
            message: 'Error updating contentnote',
            error: error.message,
        });
    }
};

const PinCheckSuccess = async (req, res) => {
    try {
        const id = req.params.id;
        const { checksuccess } = req.body;

        const checkHistoryQuery = `SELECT * FROM contentnote WHERE id = @id`;
        const existingHistory = await executeQuery(checkHistoryQuery, { id });
        // console.log(existingHistory);

        if (!existingHistory || existingHistory.length === 0) {
            return res.status(404).json({
                result: 3,
                error: 'User not found',
                data: []
            });
        }

        const updateQuery = `
            UPDATE contentnote
            SET checksuccess = 1
            WHERE id = @id
        `;
        const updateResult = await executeQuery(updateQuery, { checksuccess, id });

        res.status(200).json({
            result: 1,
            message: 'History updated successfully',
            data: [],
        });
    } catch (error) {
        console.error('Error updating contentnote:', error);
        res.status(500).json({
            result: 0,
            message: 'Error updating contentnote',
            error: error.message,
        });
    }
};

const unCheckSuccess = async (req, res) => {
    try {
        const id = req.params.id;
        const { checksuccess } = req.body;

        const checkHistoryQuery = `SELECT * FROM contentnote WHERE id = @id`;
        const existingHistory = await executeQuery(checkHistoryQuery, { id });
        // console.log(existingHistory);

        if (!existingHistory || existingHistory.length === 0) {
            return res.status(404).json({
                result: 3,
                error: 'User not found',
                data: []
            });
        }

        const updateQuery = `
            UPDATE contentnote
            SET checksuccess = 0
            WHERE id = @id
        `;
        const updateResult = await executeQuery(updateQuery, { checksuccess, id });

        res.status(200).json({
            result: 1,
            message: 'History updated successfully',
            data: [],
        });
    } catch (error) {
        console.error('Error updating contentnote:', error);
        res.status(500).json({
            result: 0,
            message: 'Error updating contentnote',
            error: error.message,
        });
    }
};

module.exports = {
    getContentNote, getContentNoteById, createContentNote, deleteContentNote, updateContent, PinContentNote, unPinContentNote, PinCheckSuccess, unCheckSuccess
};